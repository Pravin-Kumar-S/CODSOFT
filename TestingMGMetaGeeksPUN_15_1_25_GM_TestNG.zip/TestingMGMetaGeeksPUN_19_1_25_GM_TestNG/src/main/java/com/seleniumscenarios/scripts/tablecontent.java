package com.seleniumscenarios.scripts;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.Select;

public class tablecontent {
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	
	public List<String> tabledata() throws InterruptedException{
		driver.get("https://www.w3schools.com/html/html_tables.asp");
		Thread.sleep(2000);
		//List<WebElement> k=driver.findElements(By.xpath("/html/body/div[5]/div/div[2]/div[1]/div[1]/div[3]/div/table/tbody/tr"));
		//List<WebElement> k=driver.findElements(By.xpath("/html/body/div[5]/div/div[2]/div[1]/div[1]/div[3]/div/table/tbody/tr/td[2]"));
		////table[@id='customers']//tr//td[2]
		//table[@id='customers']//tr
		//List<WebElement> k=driver.findElements(By.xpath("table[@id='customers']//tr"));  --- output empty list
		List<WebElement> k=driver.findElements(By.xpath("/html/body/div[5]/div/div[2]/div[1]/div[1]/div[3]/div/table/tbody/tr//th "));
		
		int c=0;
		List<String> res=new ArrayList();
		for(int i=0;i<k.size();i++) {
			Thread.sleep(2000);
			String s=k.get(i).getText();
			System.out.println(s);
			res.add(s);
			c=c+1;
			
		}
		System.out.println(c);
		return res;
	}
	public List<WebElement> selectdropdown() throws InterruptedException{
		driver.get("https://www.amazon.in/ref=nav_logo");
		Thread.sleep(2000);
		WebElement elements =driver.findElement(By.xpath("//*[@id=\"searchDropdownBox\"]"));
		Select sel=new Select(elements);
//		sel.selectByValue(null);
//		sel.selectByVisibleText(null);
		List<WebElement> mylist=sel.getOptions();
		
		for(int i=0;i<mylist.size();i++) {
			String values=mylist.get(i).getText();
			System.out.println(values);
		}
		//sel.selectByValue("Books");
//		WebElement a=sel.getFirstSelectedOption();
//		System.out.println(a.getText());
		return mylist;
		
		
	}
	
//	public void selectbyindex() throws InterruptedException {
//		driver.get("https://demo.guru99.com/test/newtours/register.php");
//		Thread.sleep(1000);
//		WebElement element2=driver.findElement(By.name("country"));
//		Select sel=new Select(element2);
//		Thread.sleep(2000);
//		sel.selectByIndex(3);
//		element2.click();
//		//sel.selectByVisibleText("data");
//		
//	}
	public String extractalertmessage() throws InterruptedException {
		driver.get("https://mail.rediff.com/cgi-bin/login.cgi");	
		Thread.sleep(2000);
		driver.findElement(By.id("login1")).sendKeys("pravin");
		driver.findElement(By.id("password"));
		Thread.sleep(2000);
		driver.findElement(By.xpath("/html/body/div[2]/div[1]/div/div[2]/div[2]/form/button")).click();
		Alert act=driver.switchTo().alert();
		
		Thread.sleep(2000);
		
		String actmsg=act.getText();
		act.accept();
		return actmsg;
		
	}
	public void drag() throws InterruptedException {
		driver.get("https://jqueryui.com/droppable/");
		Thread.sleep(2000);
		WebElement iframe=driver.findElement(By.xpath("//*[@class='demo-frame']"));
		driver.switchTo().frame(iframe);
		WebElement source=driver.findElement(By.id("draggable"));
		WebElement dest=driver.findElement(By.id("droppable"));
		
		Actions act=new Actions(driver);
		Thread.sleep(2000);
		act.dragAndDrop(source, dest).perform();
		
		
		
		
		
	}
	
}
