package seleniumaccess_script;

import org.testng.annotations.Test;

import com.seleniumscenarios.scripts.tablecontent;

import junit.framework.Assert;

import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;


import org.testng.annotations.Test;

public class seleniumfirefox2 {
	List<String> exp= List.of("Compay", "Contact", "Country");
	tablecontent obj=new tablecontent();
	WebDriver wd=new ChromeDriver();
//  @Test(priority=2)
//  public void f() throws InterruptedException {
//	  obj.init(wd);
//	  List<String> kk=obj.tabledata();
//	  System.out.println(kk);
//	  //Assert.assertEquals(exp, kk);
//  }
//  
//  @Test(priority=1)
//  public void fk() throws InterruptedException {
//	  obj.init(wd);
////	  List<WebElement> ans=obj.selectdropdown();
////	  System.out.println(ans);
//	  obj.selectbyindex();
//	  
//  }
  @Test(priority=1)
  public void f() throws InterruptedException {
	  obj.init(wd);
	  String a=obj.extractalertmessage();
	  System.out.println(a);
	  
  }
	
//	@Test
//	public void d() throws InterruptedException {
//		obj.init(wd);
//		obj.drag();
//	}
}
