package SelniumDay2;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.seleniumday2.lib.dataproviderlogin;

public class Login_test {
	dataproviderlogin obj=new dataproviderlogin();
	WebDriver dp=new ChromeDriver();
  @Test(dataProvider="dp")
  public void f(String a,String b,String c) throws InterruptedException {
	  obj.init(dp);
	  String h=obj.Launch_OcartLogin();
	  Thread.sleep(2000);
	  if(c.equals("pass")) {
		  String k=obj.performloginvalid(a, b);
		  obj.logout();
		  
		  System.out.println(k);
	  }
	  else {
		  String k=obj.performlogininvalid(a, b);
		  System.out.println(k);
	  }
	  System.out.println(h);
  }
  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { "gayatrimis2@gmail.com", "gayatrimis2@gmail.com" ,"pass"},
      new Object[] { "gayatrimis2@gma.com", "gayatrimis2@gmil.com" ,"fail"}
     
    };
    
    
  }
 
}
