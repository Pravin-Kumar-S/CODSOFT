package com.seleniumday2.lib;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

public class dataproviderlogin {
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	public String Launch_OcartLogin() {
		driver.get("https://awesomeqa.com/ui/index.php?route=account/login");
		String Loginpgtitle=driver.getTitle();
		return Loginpgtitle;
	}
	
	public String performloginvalid(String email,String password) {
		//driver.manage().window().maximize();
		driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys(email);
		driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys(password);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		
		String message= driver.findElement(By.xpath("//h2[contains(text(),'My Orders')]")).getText();
		
		
		return message;
		
		
	}
	public void logout() {
		Actions act=new Actions(driver);
		WebElement e1=driver.findElement(By.xpath("//*[@id=\'top-links\']/ul/li[2]/a/i"));
		act.moveToElement(e1).click().build().perform();
		driver.findElement(By.xpath("//*[@id=\'top-links\']/ul/li[2]/ul/li[5]/a")).click();
		driver.findElement(By.xpath("//*[@id=\"common-success\"]/ul/li[2]/a")).click();
	}
	
	
	public String performlogininvalid(String email1,String password1) {
		driver.findElement(By.xpath("//input[@id='input-email']")).sendKeys(email1);
		driver.findElement(By.xpath("//input[@id='input-password']")).sendKeys(password1);
		driver.findElement(By.xpath("//input[@type='submit']")).click();
		String message= driver.findElement(By.xpath("//*[contains(text(),' Warning: No match for E-Mail Address and/or Password.')]")).getText();
		return message;
	}

}
