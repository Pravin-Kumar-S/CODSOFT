package com.accessSeleniumDay1_lib;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.selenium.lib.seleniumDay1;
import com.selenium.lib.seleniumDay1_commonmethod;

import junit.framework.Assert;

public class Awesome_TC_01 {
	WebDriver driver=new ChromeDriver();
	seleniumDay1 pg1=new seleniumDay1();
	seleniumDay1_commonmethod pg2=new seleniumDay1_commonmethod();
	List<String> exp_list=new ArrayList<>();
	String Exp_HomePg="Home page title is Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
	
  @Test(priority=1)
  public void InvokeApp_Awesome() {
	  pg2.init0(driver);
	  pg2.Maximize();
	  pg2.delete_Cookies();
	  
	  pg1.init(driver);
	  pg1.InvokeAwesomeQaApp();
	  
	  //System.out.println(pg1.AwesomeHome_PageTitle()); 
  }
  @Test(priority=2)
  public void Fetch_And_Validate_Title() {
	  String HomePageTitle=pg1.AwesomeHome_PageTitle();
	  System.out.println("Home page title is "+HomePageTitle);
	  //assertion
	  
	  //Assert.assertEquals(HomePageTitle, Exp_HomePg);
  }
  @Test(priority=3)
  public void Counts() throws InterruptedException {
	  List<WebElement> k=pg1.countlink();
	  System.out.println("no of links "+k);
	  //Assert.assertEquals(exp_list, k);
  }
  
}
