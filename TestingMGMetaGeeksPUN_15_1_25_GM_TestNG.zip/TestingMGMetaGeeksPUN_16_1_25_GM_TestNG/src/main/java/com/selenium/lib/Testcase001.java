package com.selenium.lib;
import org.openqa.selenium.*;
import org.openqa.selenium.chrome.ChromeDriver;
public class Testcase001 {

	public static void main(String[] args) {
		WebDriver wd=new ChromeDriver();
		wd.get("https://awesomeqa.com/ui");
		String PgTitle=wd.getTitle();
		System.out.println(PgTitle);
		// TODO Auto-generated method stub

	}

}
