package com.selenium.lib;
import java.util.List;

import org.openqa.selenium.*;
import org.openqa.selenium.WebElement;


public class seleniumDay1 {
	WebDriver driver;
	public void init(WebDriver driver) {
		this.driver=driver;
	}
	public void InvokeAwesomeQaApp() {
		driver.get("https://www.amazon.in/ref=nav_logo");
		
	}
	public String AwesomeHome_PageTitle() {
		String pgTitleHome=driver.getTitle();
		return pgTitleHome;
		
	}
	public List countlink() throws InterruptedException {
		List <WebElement> Links= driver.findElements(By.tagName("a"));
		int count=Links.size();
		Thread.sleep(2000);
		System.out.println(count);
		for(int i=1;i<count;i++) {
			String name=Links.get(i).getText();
			System.out.println(name);
		}
		return Links;
		
	}

}
