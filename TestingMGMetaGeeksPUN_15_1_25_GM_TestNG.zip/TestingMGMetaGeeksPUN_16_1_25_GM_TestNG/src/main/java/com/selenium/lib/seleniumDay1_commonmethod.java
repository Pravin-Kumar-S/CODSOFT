package com.selenium.lib;

import org.openqa.selenium.WebDriver;

public class seleniumDay1_commonmethod {
	WebDriver driver;
	public void init0(WebDriver driver) {
		this.driver=driver;
	}
	public void Maximize() {
		driver.manage().window().maximize();
		
	}
	//delte all cookies
	public void delete_Cookies() {
		driver.manage().deleteAllCookies();
	}
	public void navigate_back() {
		driver.navigate().back();
		
	}
	public void navigate_front() {
		driver.navigate().forward();
		
	}
	public void navigate_refresh() {
		driver.navigate().refresh();
		
	}
	public String Extract_pagesource() {
		return driver.getPageSource();
	}

}
