package restassured;

import io.restassured.RestAssured;
import io.restassured.response.Response;

public class reqres {
	public static void main(String[] args) {
		RestAssured.baseURI="https://reqres.in";
        String endp="/api/users";
        String APIKeys="reqres-free-v1";
        
        Response res=RestAssured.given().relaxedHTTPSValidation().auth().oauth2(APIKeys).when().get(endp).then().extract().response();
        int scode=res.getStatusCode();
        System.out.println(scode);
	}

}
