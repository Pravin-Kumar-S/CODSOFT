package restassured;

import org.testng.annotations.Test;

import junit.framework.Assert;
import restpkg.librest;

public class restapitest {
	int k=200;
	librest obj= new librest();
	Test_UserList obj1=new Test_UserList();
//  @Test
//  public void f() {
//	  int code=obj.statuscode();
//	  Assert.assertEquals(k, code);
//  }
  @Test
  public void f() {
//	  String line=obj1.sline();
//	  Integer code=obj1.scode();
//	  String body=obj1.sbody();
//	  System.out.println(line+'\n'+code+'\n'+body);
	  //obj1.createrepo();
	  obj1.deleterepo();
  }
}
