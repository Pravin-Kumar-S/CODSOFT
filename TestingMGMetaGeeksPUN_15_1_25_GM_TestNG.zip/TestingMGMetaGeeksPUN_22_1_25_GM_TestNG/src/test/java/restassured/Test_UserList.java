package restassured;

import io.restassured.RestAssured;
import io.restassured.response.Response;
import io.restassured.response.ResponseBody;

public class Test_UserList {
	String token="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";
	String ep2="/users/Pravin-Kumar-S/repos";
	
	public String sline() {
		RestAssured.baseURI="https://api.github.com";
		String line=RestAssured.given().relaxedHTTPSValidation().header("Authorization", "Bearer "+token).get(ep2).statusLine();
		return line;
		
	}
	public Integer scode() {
		RestAssured.baseURI="https://api.github.com";
		Integer code=RestAssured.given().relaxedHTTPSValidation().header("Authorization", "Bearer "+token).get(ep2).statusCode();
		return code;
		
	}
	public String sbody() {
		String body=RestAssured.given().relaxedHTTPSValidation().header("Authorization", "Bearer "+token).get(ep2).getBody().asPrettyString();
		return body;
		
	}
	
	public void createrepo() {
		RestAssured.baseURI="https://api.github.com";
		String body="{\"name\":\"rest-assured-testng-2\",\"private\":false}";
		
//		Response responses = RestAssured .given() .relaxedHTTPSValidation() .header("Authorization", "Bearer " + token) .header("Accept", "application/vnd.github+json") .header("Content-Type", "application/json") .body(body) .post("/user/repos") .then() .extract() .response();
		
		Response responses = RestAssured .given() 
				.relaxedHTTPSValidation() .header("Authorization", "Bearer " + token).when().header("Accept", "application/vnd.github+json").body(body).post("/user/repos");
		
		System.out.println("Status code: "+responses.getStatusCode());
		System.out.println("Response body:\n" +responses.getBody().asPrettyString());
		
		
		
	}
	
	public void deleterepo() {
		RestAssured.baseURI="https://api.github.com";
		String body="{\"name\":\"rest-assured-testng-2\",\"private\":false}";
		Response responses = RestAssured .given() 
				.relaxedHTTPSValidation() .header("Authorization", "Bearer " + token).when().header("Accept", "application/vnd.github+json")
				.when().delete("/repos/Pravin-Kumar-S/rest-assured-testng-2");
		
		System.out.println("Status code: "+responses.getStatusCode());
		System.out.println("Response body:\n" +responses.getBody().asPrettyString());
		
	}
	
	
	

}
