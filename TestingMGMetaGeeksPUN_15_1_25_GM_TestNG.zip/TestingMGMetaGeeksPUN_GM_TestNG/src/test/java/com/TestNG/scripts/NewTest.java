package com.TestNG.scripts;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import junit.framework.Assert;
@Test
public class NewTest {
  
  public void f() {
	  System.out.println("new class");
  }
  @BeforeTest
  public void ut() {
	  System.out.println("old class");
  }
  @Test
  public void a() {
	  SoftAssert obj = new SoftAssert();
	  obj.assertEquals(8,8,"Math failed");
	  obj.assertFalse(10>5,"conditon fail");
	  //obj.assertAll();
	  System.out.println("hello");
	  
	  //System.out.println("middle class");
  }
}
