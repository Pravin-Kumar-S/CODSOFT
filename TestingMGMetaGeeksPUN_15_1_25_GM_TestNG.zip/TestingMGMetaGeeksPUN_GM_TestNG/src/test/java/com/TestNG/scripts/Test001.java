package com.TestNG.scripts;

import org.testng.annotations.Test;

public class Test001 {
  @Test(groups={"smoketest","regroup"})
  public void banana() {
	  System.out.println("inside test banana");
  }
  @Test(groups= {"smoketest"})
  public void apple() {
	  System.out.println("inside test apple");
  }
}
