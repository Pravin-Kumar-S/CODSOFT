
package com.sel.day7;

import java.util.List;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class lib2 extends base1 {
    public lib2(WebDriver driver) {
        super(driver);
    }

    public int linkcount() {
        List<WebElement> links = driver.findElements(By.tagName("a"));
        return links.size();
    }
}
