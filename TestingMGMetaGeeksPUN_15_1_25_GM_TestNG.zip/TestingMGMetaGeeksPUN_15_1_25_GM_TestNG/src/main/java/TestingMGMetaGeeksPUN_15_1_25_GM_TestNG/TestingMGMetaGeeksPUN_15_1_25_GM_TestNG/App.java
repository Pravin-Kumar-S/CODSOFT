package TestingMGMetaGeeksPUN_15_1_25_GM_TestNG.TestingMGMetaGeeksPUN_15_1_25_GM_TestNG;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
