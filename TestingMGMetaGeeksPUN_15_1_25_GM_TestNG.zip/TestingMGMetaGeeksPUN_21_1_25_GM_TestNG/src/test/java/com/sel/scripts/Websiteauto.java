package com.sel.scripts;

import org.testng.annotations.Test;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
public class Websiteauto {
	WebDriver d=new ChromeDriver();
//  @Test
//  public void f() throws InterruptedException {
//	  d.get("https://www.pdfgear.com/word-to-pdf");
//	  Thread.sleep(1000);
//	  d.findElement(By.xpath("//*[@id=\"file1\"]")).sendKeys("C:/Users/spravin.kumar/Downloads/new.docx");
//	  Thread.sleep(10000);
//	  d.findElement(By.xpath("/html/body/div[1]/div[1]/div/div[2]/div[1]/div[4]/div/div[1]/div[1]/div[2]/a")).click();
//	 
//  
//  }
//  @Test
//  public void f() throws InterruptedException {
//	  d.get("https://the-internet.herokuapp.com/key_presses");
//	  Thread.sleep(2000);
//	  d.findElement(By.xpath("//*[@id='target']")).sendKeys(Keys.NUMPAD4);
//	  
//	 
//  
//  }
//  @Test
//  public void h() throws InterruptedException {
//	  d.get("https://the-internet.herokuapp.com/inputs");
//	  Thread.sleep(2000);
//	  d.findElement(By.xpath("//*[@type='number']")).sendKeys(String.valueOf(5));
//  }
//  
	
	@Test
	public void implcitwait() {
		d.get("https://the-internet.herokuapp.com/");
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		WebElement num=d.findElement(By.xpath("//*[contains(text(),'1212')]"));
		d.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));
		String a=num.getText();
		System.out.println(a);
	}
}
