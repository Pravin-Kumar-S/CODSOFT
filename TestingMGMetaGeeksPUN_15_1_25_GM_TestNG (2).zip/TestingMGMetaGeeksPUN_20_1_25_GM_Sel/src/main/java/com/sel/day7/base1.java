
package com.sel.day7;

import org.openqa.selenium.WebDriver;

public class base1 {
    protected WebDriver driver;

    public base1(WebDriver driver) {
        this.driver = driver;
    }
}
