package com.sel.day7;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class curapage1 {
	//init
	//locator
	//steps automation
	WebDriver d;
	public void cura_page1_init(WebDriver d) {
		this.d=d;
	}
	
	By validpg1=By.xpath("//*[contins(text(),'We Care About Your Health')]");
	By mkap=By.id("btn-make-appointment");
	//By mkappfrom=By.xpath("//h2[contains(text(),'Make Appointment')]");
	
	
	public String launch(String url) {
		d.get(url);
		String val1="The app is launched successfully";
		String val2="Check the url again!";
		
		if(d.findElement(mkap).isDisplayed()) {
			return val1;
		}
		else {
			return val2;
		}
	}
	
	public String clickon() {
		
		d.findElement(mkap).click();
		//String mkaptext=d.findElement(mkappfrom).getText();
		//return mkaptext;
		return null;
	}

}
