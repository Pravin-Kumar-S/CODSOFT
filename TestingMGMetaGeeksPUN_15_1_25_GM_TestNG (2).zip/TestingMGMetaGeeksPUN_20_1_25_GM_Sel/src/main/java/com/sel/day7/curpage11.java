package com.sel.day7;

import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

import org.openqa.selenium.Alert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.ui.Select;


public class curpage11 {
	WebDriver d;
	Properties p=new Properties();
	FileReader fr;
	By unm=By.name("username");
	By psw=By.name("password");
	By btn=By.id("btn-login");
	public void cura_page11_init(WebDriver d) {
		this.d=d;
	}
	public void login() throws InterruptedException, IOException {
		
		String path="C:/Users/spravin.kumar//eclipse-workspace//TestingMGMetaGeeksPUN_20_1_25_GM_TestNG//data//data.properties";
		fr=new FileReader(path);
		p.load(fr);
		
//		d.findElement(unm).sendKeys("John Doe");
//	
//		d.findElement(psw).sendKeys("ThisIsNotAPassword");
		
		d.findElement(unm).sendKeys(p.getProperty("username1"));
		d.findElement(psw).sendKeys(p.getProperty("password1"));
		Thread.sleep(2000);
		d.findElement(btn).click();
//		Alert act=d.switchTo().alert();
//		Thread.sleep(2000);
//		act.accept();
	}
	public void dropdown() throws InterruptedException {
		WebElement elements =d.findElement(By.xpath("//*[@id=\"combo_facility\"]"));
		Select sel=new Select(elements);
		Thread.sleep(2000);
		sel.selectByIndex(2);
		elements.click();
		
		d.findElement(By.xpath("/html/body/section/div/div/form/div[2]/div/label")).click();
		d.findElement(By.xpath("//*[@id=\"txt_visit_date\"]")).sendKeys("01/01/2003");
		d.findElement(By.xpath("//*[@id=\"txt_comment\"]")).sendKeys("this is a sample");
		d.findElement(By.xpath("//*[@id=\"btn-book-appointment\"]")).click();
		d.findElement(By.xpath("/html/body/section/div/div/div[7]/p/a")).click();
		Thread.sleep(2000);
		d.quit();
		
		//Actions act=new Actions(d);
	}

}
