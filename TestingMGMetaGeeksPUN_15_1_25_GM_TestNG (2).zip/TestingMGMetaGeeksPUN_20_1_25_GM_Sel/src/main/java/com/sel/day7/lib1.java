
package com.sel.day7;

import org.openqa.selenium.WebDriver;

public class lib1 extends base1 {
    public lib1(WebDriver driver) {
        super(driver);
    }

    public String gettitle() {
        driver.get("https://awesomeqa.com/ui/index.php?route=account/register");
        return driver.getTitle();
    }
}

