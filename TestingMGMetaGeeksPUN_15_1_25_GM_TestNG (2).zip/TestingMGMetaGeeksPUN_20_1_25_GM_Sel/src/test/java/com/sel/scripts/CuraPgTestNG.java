package com.sel.scripts;

import org.testng.annotations.Test;

import com.sel.day7.curapage1;
import com.sel.day7.curpage11;

import java.io.IOException;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class CuraPgTestNG {
	WebDriver d=new FirefoxDriver();
	curapage1 c1=new curapage1();
	curpage11 c2=new curpage11();
  @Test(priority=1)
  public void appinvoke() {
	  c1.cura_page1_init(d);
	  String a=c1.launch("https://katalon-demo-cura.herokuapp.com/");
	  System.out.println(a);
	  
  }
  @Test(priority=2)
  public void clickmakeappointment() {
	  String k=c1.clickon();
	  System.out.println(k);
  }
  @Test(priority=3)
  public void performlogin() throws InterruptedException, IOException {
	  c2.cura_page11_init(d);
	  c2.login();
	  c2.dropdown();
  }
}
