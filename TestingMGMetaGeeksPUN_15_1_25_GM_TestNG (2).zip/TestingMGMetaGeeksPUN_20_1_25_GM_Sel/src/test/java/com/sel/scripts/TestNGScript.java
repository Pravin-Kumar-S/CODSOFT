
package com.sel.scripts;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;

import com.sel.day7.base1;
import com.sel.day7.lib1;
import com.sel.day7.lib2;

public class TestNGScript {
    private WebDriver driver;
    private lib1 obj1;
    private lib2 obj2;

    @BeforeClass
    public void setUp() {
        driver = new ChromeDriver();
        obj1 = new lib1(driver);
        obj2 = new lib2(driver);
    }

    @Test
    public void f() {
        String a = obj1.gettitle();
        System.out.println(a);
        int n = obj2.linkcount();
        System.out.println(n);
    }

   
}
