package com.seleniumday2.lib;

import org.testng.annotations.Test;

public class dataproviderloginTest {
  @Test
  public void f() {
  }
}
