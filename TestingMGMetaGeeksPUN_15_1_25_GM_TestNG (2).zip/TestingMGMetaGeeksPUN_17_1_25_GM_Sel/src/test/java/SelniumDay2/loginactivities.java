package SelniumDay2;

import org.testng.annotations.Test;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

import com.seleniumday2.lib.SeleniumDay2;

import junit.framework.Assert;

public class loginactivities {
	WebDriver wb=new ChromeDriver();
	SeleniumDay2 obj=new SeleniumDay2();
	String exp="My Account";
	
	
	
	
  @Test(priority=1)
  public void f() throws InterruptedException {
	  obj.init(wb);
	  System.out.println(obj.Launch_OcartLogin());
	  Thread.sleep(2000);
	  String a=obj.performloginvalid("gayatrimis2@gmail.com", "gayatrimis2@gmail.com");
	  Thread.sleep(4000);
	  System.out.println(a);
	  Thread.sleep(4000);
	  

	  //Assert.assertEquals(exp, a);
	  
  }
  @Test(priority=2)
  public void fz() throws InterruptedException {
	  obj.init(wb);
	  System.out.println(obj.Launch_OcartLogin());
	  Thread.sleep(2000);
	  String b=obj.performlogininvalid("gayatrimis2@gm", "gaya@gmail.com");
	  Thread.sleep(4000);
	  System.out.println(b);
	  Thread.sleep(4000);
	  

	  //Assert.assertEquals(exp, a);
	  
  }
  
  
}
