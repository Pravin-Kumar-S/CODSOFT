package runner;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(features= {"src/test/java/feature/docu.feature"},
tags="@tag",
glue="stepdef"


)

public class testrun extends AbstractTestNGCucumberTests{

}
