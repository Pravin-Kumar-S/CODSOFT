package stepdef;

import java.time.Duration;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.Before;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class testcase001_documentation {
	WebDriver driver;
	
	@Given("the user must be in chrome browser")
	public void presetup() {
		driver=new ChromeDriver();
	}
	
	@Given ("The user is in cucumber.io home page")
	public void user_home_page() throws InterruptedException {
		String baseurl="https://cucumber.io";
		driver.get(baseurl);
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
		
	}
	@When ("The user clicks on Documentation info")
	public void click() throws InterruptedException {
		WebElement doclink=driver.findElement(By.xpath("//*[contains(text(),'Documentation')]"));
		doclink.click();
		//Thread.sleep(2000);
		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(2));
		
	}
	@Then ("The user can view the page content with what is cucumber?")
	public void view() {
		WebElement datastr=driver.findElement(By.xpath("//h2[contains(text(),'What is Cucumber?')]"));
		String data=datastr.getText();
		System.out.println(data);
		
		
	}

}
