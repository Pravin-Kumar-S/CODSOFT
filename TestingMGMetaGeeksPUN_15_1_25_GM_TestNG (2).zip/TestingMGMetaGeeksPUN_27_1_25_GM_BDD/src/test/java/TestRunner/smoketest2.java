package TestRunner;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(features= {"src/test/java/featureName/feature2.feature"},
tags="@tag6 or @tag7",
glue="bddstepdef",
plugin= {
		"pretty",
		"html:target/cucumber-reports/cucumber.html",
		"json:target/cucumber-reports/cucumbertestreport.json",
		"junit:target/cucumber-reports/cucumbertest.xml"
}

)

public class smoketest2 extends AbstractTestNGCucumberTests{

}
