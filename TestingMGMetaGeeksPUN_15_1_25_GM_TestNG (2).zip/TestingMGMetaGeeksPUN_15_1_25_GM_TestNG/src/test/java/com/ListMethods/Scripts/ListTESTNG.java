package com.ListMethods.Scripts;

import java.util.Arrays;
import java.util.List;

import org.testng.annotations.Test;

import com.ListMethods.library.ListMethod;

import junit.framework.Assert;

public class ListTESTNG {
	ListMethod obj=new ListMethod();
	boolean exp=true;
	Object expArr[]= {11,12,13,14,15,16};
	
  @Test
  public void f() {
	  List<String> l1=Arrays.asList("Mumbai","Chennai","Pune");
	  boolean res=obj.ArrayListTest(l1);
	  System.out.println(res);
	  Assert.assertEquals(res,exp);
  }
  
  @Test
  public void f2() {
	  List <Integer> arr1=Arrays.asList(11,12,13,14,15,16);
	  Object act[]=obj.ConvertListToArray(arr1);
	  Assert.assertEquals(expArr,act);
	  
  }
}
