package com.ListMethods.library;
import java.util.*;

public class ListMethod {
	public boolean ArrayListTest(List <String> l1) {
		boolean l3=l1.contains("Pune");
		return l3;
	}
	public Object[] ConvertListToArray(List<Integer> ListTestData) {
		Object arr1[]=ListTestData.toArray();
		return arr1;
	}
	
	

}
