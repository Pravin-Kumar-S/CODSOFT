import org.testng.annotations.Test;

public class ListMethod {
  @Test
  public void f() {
  }
}
