package seleniumaccess_script;

import org.testng.annotations.Test;

import java.util.List;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import com.seleniumscenarios.scripts.seleniumscenario1;

public class seleniumfirefox {
	seleniumscenario1 obj=new seleniumscenario1();
	WebDriver wd=new FirefoxDriver();
  @Test
  public void f() throws InterruptedException {
	  obj.init(wd);
	  List<String> finals=obj.search();
	  System.out.println(finals);
  }
}
