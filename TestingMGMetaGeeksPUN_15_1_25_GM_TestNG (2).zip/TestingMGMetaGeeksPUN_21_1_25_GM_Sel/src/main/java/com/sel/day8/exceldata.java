package com.sel.day8;

import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class exceldata {
	public static void main(String[] args) throws IOException {
		String path="C:/Users/spravin.kumar/eclipse-workspace/TestingMGMetaGeeksPUN_21_1_25_GM_Sel/datas/data.xlsx";
		FileInputStream fis= new FileInputStream(path);
		Workbook workbook=new XSSFWorkbook(fis);
		Sheet sheet=workbook.getSheet("Sheet1");
		
		for(int i=0;i<=sheet.getLastRowNum();i++) {
			Row row=sheet.getRow(i);
			if(row==null)continue;
			String username=row.getCell(0).getStringCellValue();
			String passwords=row.getCell(1).getStringCellValue();
			System.out.println(username);
			System.out.println(passwords);
			
		}
	}

}
