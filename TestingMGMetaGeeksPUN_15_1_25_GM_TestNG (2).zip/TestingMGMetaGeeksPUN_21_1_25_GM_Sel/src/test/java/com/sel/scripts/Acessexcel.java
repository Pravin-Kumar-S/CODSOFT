package com.sel.scripts;

import java.io.IOException;

import org.testng.annotations.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.sel.day8.ExcelRead1;

public class Acessexcel {
	WebDriver d=new ChromeDriver();
	ExcelRead1 obj= new ExcelRead1();
  @Test
  public void f() throws IOException {
	  d.get("https://www.google.com");
	  String res=obj.Readcelldata(0, 1);
	  System.out.println(res);
	  d.findElement(By.name("q")).sendKeys(res);
	  
	  
	  
  }
  
  
}
