package bdd1;

import io.cucumber.java.After;
import io.cucumber.java.Before;
import io.cucumber.java.BeforeStep;

public class HookTest {
	@Before
	public void beforetest() {
		System.out.println("Before Test");
	}
	@After
	public void aftetest() {
		System.out.println("After test");
	}
	
	@Before("@tag6 and not @tag7")
	public void a() {
		System.out.println("before tag");
	}
	@After("@tag6 or @tag7")
	public void b() {
		System.out.println("after tag");
	}
	@BeforeStep("@tag6")
	public void d() {
		System.out.println("before each step");
	}

}
