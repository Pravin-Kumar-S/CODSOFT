package bdd1;
 
import org.testng.annotations.Test;
 
import io.cucumber.testng.CucumberOptions;
import io.cucumber.testng.AbstractTestNGCucumberTests;
@CucumberOptions(features= {"src/test/java/bdd1"},
glue="bdd1",
tags="@tag2 and not @tag1"
)
public class smokeTest1 extends AbstractTestNGCucumberTests{
  
}
 