package bdd1;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class Stepdef2 {
	@Given("I want to write a step with {string}")
	public void step(String name) {
		System.out.println(name);
	}
	@When("I want to enter {int} id as idnum")
	public void idtest(int id) {
		System.out.println(id);
	}
	@And("I want to enter {double} as salary")
		public void saltest(double sal) {
			System.out.println(sal);
		}
	
	@Given ("The user is in login form")
	public void h1() {
		System.out.println("The user is in login form");
	}
    @When ("The user enters {string} in username field")
    public void h2(String Username) {
		System.out.println(Username);
	}
    @And ("The user enters {string} in password field")
    public void h3(String password) {
    	System.out.println(password);
	}
    @And ("The user clicks on login button")
    public void h4() {
    	System.out.println("The user clicks on login button");
	}
    @Then ("the user gets the status message as {string} in alert")
    public void h5(String Status) {
    	System.out.println(Status);
	}
	

}
