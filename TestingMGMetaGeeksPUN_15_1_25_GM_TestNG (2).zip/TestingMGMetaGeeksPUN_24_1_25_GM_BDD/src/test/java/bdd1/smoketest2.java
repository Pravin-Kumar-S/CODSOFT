package bdd1;

import org.testng.annotations.Test;

import io.cucumber.testng.AbstractTestNGCucumberTests;
import io.cucumber.testng.CucumberOptions;
@CucumberOptions(features= {"src/test/java/bdd1/feature2.feature"},
tags="@tag6 or @tag7",
glue="bdd1"

)

public class smoketest2 extends AbstractTestNGCucumberTests{

}
