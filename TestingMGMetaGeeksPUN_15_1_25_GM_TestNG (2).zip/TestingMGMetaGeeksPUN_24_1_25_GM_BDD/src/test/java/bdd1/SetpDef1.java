package bdd1;
 
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
 
public class SetpDef1 {
	@Given ("I am holding the calculator")
	public void step1() {
		System.out.println("I am holding the calculator");
	}
    @When ("I enter the first number" )
    public void step2() {
		System.out.println("I enter the first number");
	}
    @And ("I click on + symbol")
    public void step3() {
		System.out.println("I click on + symbol");
    }
    @And ("I enter the third number")
    public void step4() {
		System.out.println("I enter the third number");
	}
    @Then ("I must be able to view the sum of the numbers")
    public void step5 () {
		System.out.println("I must be able to view the sum of the numbers");
	}
	@Given ("a global admin named Greg")
	public void step6() {
		System.out.println("a global admin named Greg");
	}
	@And ("a blog named Gregs anti-tax rants")
	public void step7() {
		System.out.println("a blog named Gregs anti-tax rants");
	}
	@Given ("I am holding the name")
	public void step8() {
		System.out.println("I am holding the name");
	}
    @When ("I enter the first name")
    public void step9() {
		System.out.println("I enter the first name");
	}
    @And ("I click on name")
    public void step10() {
		System.out.println("I click on name");
	}
    @And ("I enter the second name")
    public void step11() {
		System.out.println("I enter the second name");
	}
    @Then ("At last give the full name.")
    public void step12() {
		System.out.println("At last give the full name.");
	}
}