package com.TestNG.scripts;

import org.testng.annotations.AfterClass;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.BeforeSuite;
import org.testng.annotations.BeforeTest;


public class Testsample {
  @BeforeTest
  public void BeforeTestExecute() {
	  System.out.println("this will execute before the test");
  }
  @AfterTest(groups= {"regroup"})
  public void AfterTestExecute() {
	  System.out.println("this will execute after the test");
  }
  @BeforeClass
  public void BeforeClassExecute() {
	  System.out.println("this will execute before the class");
  }
  @AfterClass
  
  
  
  
  public void AfterClassExecute() {
	  System.out.println("this will execute after the class");
  }
  @BeforeMethod
  public void BeforeMethodExecute() {
	  System.out.println("this will execute before the method");
  }
  @AfterMethod
  public void AfterMethodExecute() {
	  System.out.println("this will execute after the method");
  }
  @BeforeSuite
  public void BeforeSuiteExecute() {
	  System.out.println("this will execute before the suite");
  }
  @AfterSuite
  public void AfterSuiteExecute() {
	  System.out.println("this will execute after the suite");
  }
  
}
