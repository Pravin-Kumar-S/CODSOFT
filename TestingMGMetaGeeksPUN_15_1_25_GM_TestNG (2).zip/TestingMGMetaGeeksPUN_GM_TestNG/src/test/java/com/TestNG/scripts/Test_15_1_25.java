package com.TestNG.scripts;

import org.testng.annotations.Test;
import org.testng.annotations.DataProvider;

public class Test_15_1_25 {
  @Test(dataProvider = "dp")
  public void f(Integer Empid, String EmpNm, Integer EmpAge) {
	  System.out.println("Emp id is"+" "+Empid);
	  System.out.println("Emp name is"+" "+EmpNm);
	  System.out.println("Emp age is"+" "+EmpAge);
	  
  }
  @Test(dataProvider = "dp2")
  public void a(Integer AccNo,String AccName) {
	  System.out.println("Account no is"+" "+AccNo);
	  System.out.println("Account name is"+" "+AccName);
  }

  @DataProvider
  public Object[][] dp() {
    return new Object[][] {
      new Object[] { 1001, "pratik",25 },
      new Object[] { 1002, "vignesh",34 },
      new Object[] { 1003, "payal",29 }
    };
    
    
  }
  @DataProvider
  public Object[][] dp2() {
    return new Object[][] {
      new Object[] { 1212121, "a"},
      new Object[] { 1313131, "b"},
      new Object[] { 1414141, "c"}
    };
    
    
  }
  
  
}
