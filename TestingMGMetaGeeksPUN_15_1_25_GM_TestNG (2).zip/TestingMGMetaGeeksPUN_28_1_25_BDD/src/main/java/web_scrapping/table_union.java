package web_scrapping;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class table_union {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		WebDriver driver=new ChromeDriver();
		driver.get("https://the-internet.herokuapp.com/tables");
		driver.manage().window().maximize();
		List<WebElement> li=driver.findElements(By.xpath("//table[@id='table2']//tr//td"));
		List<WebElement> li2=driver.findElements(By.xpath("//table[@id='table1']//tr//td"));
		System.out.println(li.size());
//		for(WebElement i:li) {
//			for(WebElement j:li2) {
//				if((i.getText()).equals(j.getText())) {
//					System.out.println(i.getText());
//				}
//			}
//			
//			
//		}
		for(WebElement i:li) {
			System.out.println(i.getText());
		}
		

	}

}
