package stepdef;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;

import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.When;
import io.cucumber.messages.internal.com.google.common.io.Files;

//pom class means just a step def with only implementation and the declaration part should be in base utility class
//base utility
//step def
//feature
//runner
public class stepdef {
	String col1=null;
	String col2=null;
	public void Readcelldata() throws IOException {


		
	}
	WebDriver driver;
	@Given ("the user must be in chrome browser")
	public void init() throws IOException {
//		String value=null;
//		Workbook wb=null;
//		FileInputStream fis=new FileInputStream("C:/Users/spravin.kumar/eclipse-workspace/TestingMGMetaGeeksPUN_28_1_25_BDD/data/input.xlsx");
//		wb=new XSSFWorkbook(fis);
//		Sheet sheet=wb.getSheetAt(0);
//		Row row=sheet.getRow(0);
//		DataFormatter df = new DataFormatter();
//		col1 = df.formatCellValue(row.getCell(0));  // Column 0 (A)
//		col2 = df.formatCellValue(row.getCell(1));
		driver=new ChromeDriver();
		
	}
	
	@Given ("The user is in login form")
	public void signup() throws IOException {
		String baseurl="https://www.bookswagon.com/login?q=signup";
		driver.get(baseurl);
		driver.manage().window().maximize();

	}
	
    @When ("The user enters {string} in username field")
    public void username(String Username) throws IOException, InterruptedException {
    	String username=null;
    	String passwords=null;
    	
    	String path="C:/Users/spravin.kumar/eclipse-workspace/TestingMGMetaGeeksPUN_28_1_25_BDD/data/input.xlsx";
		FileInputStream fis= new FileInputStream(path);
		Workbook workbook=new XSSFWorkbook(fis);
		Sheet sheet=workbook.getSheet("Sheet1");
		DataFormatter df = new DataFormatter();
		
		for(int i=0;i<=sheet.getLastRowNum();i++) {
			Row row=sheet.getRow(i);
			if(row==null)continue;
			username=df.formatCellValue(row.getCell(0));
					//row.getCell(0).getStringCellValue();
			passwords=df.formatCellValue(row.getCell(1));
					//row.getCell(1).getStringCellValue();
			
			WebElement d= driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_txtName\"]"));
			d.sendKeys(username);
			Thread.sleep(2000);
			WebElement k= driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_txtEmail\"]"));
			k.sendKeys(passwords);
			Thread.sleep(2000);
			d.clear();
			Thread.sleep(2000);
			k.clear();
			Thread.sleep(2000);
		}

    	
    }
    @And ("The user enters {string} in number field")
    public void num(String number) throws InterruptedException {
//  
//    	WebElement k= driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_txtEmail\"]"));
//    	k.sendKeys(col2);
//    	Thread.sleep(1000);
    	
    }

//    @And ("The user clicks on continue button")
//    public void continues() throws InterruptedException {
//    	driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_btnContinue\"]")).click();
//    	Thread.sleep(10000);
//    }
//    @And ("the user enter otp {string}")
//    public void otp(String otp) {
//    	WebElement j=driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_txtOTP\"]"));
//    	j.sendKeys(otp);
//    }
//    @And ("the user enter password {string}")
//    public void passes(String password) {
//    	WebElement a1=driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_txtPassword\"]"));
//    	a1.sendKeys(password);
//    	WebElement a2=driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_txtConfirmPwd\"]"));
//    	a2.sendKeys(password);
//    }
//    @And ("the user click submit")
//    public void submit() throws InterruptedException {
//    	WebElement a=driver.findElement(By.xpath("//*[@id=\"ctl00_phBody_SignUp_btnSubmit\"]"));
//    	a.click();
//    	driver.navigate().back();
//    	Thread.sleep(1000);
//    }


}
