package TestingMGMetaGeeksPUN_29_1_25_BDD.TestingMGMetaGeeksPUN_29_1_25_BDD;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
    }
}
