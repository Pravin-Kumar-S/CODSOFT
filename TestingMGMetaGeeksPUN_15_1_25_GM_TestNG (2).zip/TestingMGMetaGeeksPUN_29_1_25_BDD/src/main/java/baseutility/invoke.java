package baseutility;

import java.io.File;

import org.apache.log4j.Logger;
import io.cucumber.messages.internal.com.google.common.io.Files;
import java.io.FileInputStream;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;
import java.util.Scanner;

import org.apache.log4j.Logger;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.Reporter;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.messages.internal.com.google.common.io.Files;
import io.github.bonigarcia.wdm.WebDriverManager;

//pom class means just a step def with only implementation and the declaration part should be in base utility class
//base utility
//step def
//feature
//runner
public class invoke {
	private static final Logger log = Logger.getLogger(invoke.class);


	baseutil obj=new baseutil();
	WebDriver driver;
	//JavascriptExecutor js = (JavascriptExecutor) driver;
	public void invokes() {
		this.driver=new FirefoxDriver();
		
	}
	
	@Given ("I want to write a step with {string}") 
	public void a(String Browsers) throws IOException{
		Scanner sc=new Scanner(System.in);
		log.debug("Debug to Selenium.logs");
		log.info("Info to Selenium.logs");
		log.warn("Warn to Selenium.logs");
		log.error("Error to Selenium.logs");
		Properties p=new Properties();
		FileReader fr;
		String path="C:/Users/spravin.kumar/eclipse-workspace/TestingMGMetaGeeksPUN_29_1_25_BDD/browser_data/config.properties";
		fr=new FileReader(path);
		p.load(fr);
		
		
		if(Browsers.equals(p.getProperty("Browser"))) {
			WebDriverManager.chromedriver().setup();
			driver=new ChromeDriver();
			driver.get("https://www.amazon.in/ref=nav_logo");
			String title=driver.getTitle();
			Reporter.log("Step1"+ " "+" The Application launched sucessfully "+ "title is "+title);
			
			
		}
//		else if(Browsers.equals(p.getProperty("Browser1"))) {
//			this.driver=new FirefoxDriver();
//		}
		else if(Browsers.equals(p.getProperty("Browser2"))) {
			this.driver=new EdgeDriver();
		}

	}
	@And("i want to maximize browser")
	public void maxi() throws IOException {
		driver.manage().window().maximize();
		
		
		obj.screen(driver, "C:/Users/spravin.kumar/eclipse-workspace/TestingMGMetaGeeksPUN_29_1_25_BDD/input_data/a2.png");
		
	
	}
	@And ("navigate back")
	public void back() throws InterruptedException {
		Thread.sleep(1000);
		driver.navigate().back();
		
	}
    @And ("navigate forward")
    public void forawrd() throws InterruptedException {
    	Thread.sleep(1000);
    	driver.navigate().forward();
    	
    }
    @And ("refresh")
    public void refresh() throws InterruptedException {
    	Thread.sleep(1000);
    	driver.navigate().refresh();
    	
    }
    @And ("delete cookies")
    public void dels() throws InterruptedException {
    	Thread.sleep(1000);
    	driver.manage().deleteAllCookies();
    	
    }
    @And ("scroll {int}")
    public void scroll(int value) throws InterruptedException {
    	((JavascriptExecutor) driver).executeScript("window.scrollBy(0, arguments[0]);",value);
    	Thread.sleep(1000);
    	
    }
    public void a() throws IOException {
    	
    	String username=null;
    	String passwords=null;
    	
    	String path="C:/Users/spravin.kumar/eclipse-workspace/TestingMGMetaGeeksPUN_28_1_25_BDD/data/input.xlsx";
    	FileInputStream fis= new FileInputStream(path);
    	Workbook workbook=new XSSFWorkbook(fis);
    	Sheet sheet=workbook.getSheet("Sheet1");
    	DataFormatter df = new DataFormatter();
    	
    	for(int i=0;i<=sheet.getLastRowNum();i++) {
    		Row row=sheet.getRow(i);
    		if(row==null)continue;
    		username=df.formatCellValue(row.getCell(0));
    		//row.getCell(0).getStringCellValue();
    		//passwords=df.formatCellValue(row.getCell(1));
    		//row.getCell(1).getStringCellValue();
    		Assert.assertEquals(username, "kiran");
    		

    	}
    }
//    @Then ("close")
    public void close() throws InterruptedException {
    	Thread.sleep(1000);
    	driver.close();
    	
    }

}
