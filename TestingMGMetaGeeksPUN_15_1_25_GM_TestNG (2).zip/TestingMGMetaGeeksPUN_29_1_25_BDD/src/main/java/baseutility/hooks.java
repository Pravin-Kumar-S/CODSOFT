package baseutility;

import io.cucumber.java.After;
import io.cucumber.java.Before;

public class hooks {
//	invoke obj=new invoke();
//	@Before
//	public void k() {
//		obj.invokes();
//	}
//	@After
//	public void c() throws InterruptedException {
//		obj.close();
//	}

}
