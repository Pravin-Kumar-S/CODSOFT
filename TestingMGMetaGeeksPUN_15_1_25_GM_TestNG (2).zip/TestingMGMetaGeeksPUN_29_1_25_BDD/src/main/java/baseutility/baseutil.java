package baseutility;

import java.io.File;
import java.io.IOException;

import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import io.cucumber.messages.internal.com.google.common.io.Files;

public class baseutil {
	WebDriver driver;
	public void screen(WebDriver driver,String a) throws IOException {
		this.driver=driver;
		File src3=((TakesScreenshot)driver).getScreenshotAs(OutputType.FILE);
		Files.copy(src3,new File(a));
	}

}
