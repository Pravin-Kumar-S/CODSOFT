package com.accessSeleniumDay1_lib;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.Test;

import com.selenium.lib.seleniumDay1;
import com.selenium.lib.seleniumDay1_commonmethod;

public class Navigation_test {
	WebDriver driver=new ChromeDriver();
	seleniumDay1_commonmethod sdc=new seleniumDay1_commonmethod();
	seleniumDay1 pg1=new seleniumDay1();
  @Test
  public void f() throws InterruptedException {
	  pg1.init(driver);
	  pg1.InvokeAwesomeQaApp();
	  sdc.init0(driver);
	  Thread.sleep(2000);
	  sdc.navigate_back();
	  Thread.sleep(2000);
	  sdc.navigate_front();
	  Thread.sleep(2000);
	  sdc.navigate_refresh();
	  String pgsource=sdc.Extract_pagesource();
	  System.out.println(pgsource);
  }
 
}
