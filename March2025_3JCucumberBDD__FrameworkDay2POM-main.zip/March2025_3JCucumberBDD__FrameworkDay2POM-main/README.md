# March2025_3JCucumberBDD__FrameworkDay2POM
Selenium WebDriver , Cucumber BDD,Excel Data Driven , Reports &amp; Logs
In this sample project we used 
   SeleniumWebDriver , Java
   Cucumber BDD
   POM
   Excel - Data driven
   Reports - cucumber
